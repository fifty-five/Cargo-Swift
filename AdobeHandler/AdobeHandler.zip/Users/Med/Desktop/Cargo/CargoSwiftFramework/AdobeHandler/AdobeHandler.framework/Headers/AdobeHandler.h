//
//  AdobeHandler.h
//  AdobeHandler
//
//  Created by Julien Gil on 07/03/2018.
//  Copyright © 2018 com.fifty-five. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for AdobeHandler.
FOUNDATION_EXPORT double AdobeHandlerVersionNumber;

//! Project version string for AdobeHandler.
FOUNDATION_EXPORT const unsigned char AdobeHandlerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AdobeHandler/PublicHeader.h>

#import <ADBMobile.h>
