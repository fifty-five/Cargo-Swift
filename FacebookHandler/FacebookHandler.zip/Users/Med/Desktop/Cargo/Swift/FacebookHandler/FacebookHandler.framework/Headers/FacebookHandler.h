//
//  FacebookHandler.h
//  FacebookHandler
//
//  Created by Julien Gil on 27/02/2018.
//  Copyright © 2018 com.fifty-five. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for FacebookHandler.
FOUNDATION_EXPORT double FacebookHandlerVersionNumber;

//! Project version string for FacebookHandler.
FOUNDATION_EXPORT const unsigned char FacebookHandlerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FacebookHandler/PublicHeader.h>


