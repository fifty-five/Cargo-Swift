//
//  ATInternetHandler.h
//  ATInternetHandler
//
//  Created by Julien Gil on 02/03/2018.
//  Copyright © 2018 com.fifty-five. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ATInternetHandler.
FOUNDATION_EXPORT double ATInternetHandlerVersionNumber;

//! Project version string for ATInternetHandler.
FOUNDATION_EXPORT const unsigned char ATInternetHandlerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ATInternetHandler/PublicHeader.h>


